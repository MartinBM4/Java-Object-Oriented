package org.uma.mbd.mdInterfaces.caso2;

@FunctionalInterface
public interface Predicado {
	boolean test(Persona p);
}
